package com.praga.springdemo.aopdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AopDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
