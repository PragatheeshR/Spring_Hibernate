package com.springboot.learning.collegeregister;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollegeRegisterApplicationTests {

	@Test
	void contextLoads() {
	}

}
