package com.praga.spring.demo.cruddemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CruddemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
