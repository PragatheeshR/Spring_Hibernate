package com.praga.springlearn.springmvcvalidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcValidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcValidationApplication.class, args);
	}

}
